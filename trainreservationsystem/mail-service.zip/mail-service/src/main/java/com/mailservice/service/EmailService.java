package com.mailservice.service;

public interface EmailService {
    public void sendSimpleEmail(String toEmail);
}
